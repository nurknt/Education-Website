from django.shortcuts import render
from news.models import Articles

def index(request):
    news = Articles.objects.order_by('-date')
    return render(request, 'news/news_home.html', {'news': news})


def offers(request):
    return render(request, 'main/offers.html')


def About(request):
    return render(request, 'main/About.html')


def contacts(request):
    return render(request, 'main/contacts.html')


def contacts(request):
    return render(request, 'main/contacts.html')


def python(request):
    return render(request, 'main/python.html')


def news(request):
    news = Articles.objects.order_by('-date')
    return render(request, 'main/news.html', {'news': news})
