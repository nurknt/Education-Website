from django.urls import path
from . import views
from news import views as news_views

urlpatterns = [
    path('', views.index, name='news_home'),
    path('offers', views.offers, name='offers'),
    path('About', views.About, name='About'),
    path('contacts', views.contacts, name='contacts'),
    path('python', views.python, name='python'),

    path('news', views.news, name='news'),


    path('create', news_views.create, name='create'),
    path('<int:pk>', news_views.NewsDetailView.as_view(), name='news-detail'),
    path('<int:pk>/update', news_views.NewsUpdateView.as_view(), name='news-update'),
    path('<int:pk>/delete', news_views.NewsDeleteView.as_view(), name='news-delete')
]
